# 🌐 IPvTri+ Auto DNS Super Changer — PRO (v1.4)

Next‑gen DNS switching with IPvTri+ metadata, VPN awareness, trusted DNS enforcement, and now:
- `--log-level` (DEBUG/INFO/WARNING/ERROR)
- CSV mirroring (`--csv logs/ipvtri_dns.csv`)
- System tray icon (`--tray`) — green/yellow/red status
- Security options: `--strict-only-trusted`, `--only-physical`, `--enforce-doh`
- Optional encrypted log mirror (`--encrypt-logs`) using `cryptography`

## Files
- `ipvtri_dns_super_changer_PRO.py` — main script
- `Run_IPvTri_DNS_PRO.bat` — Windows launcher with common flags
- `trusted_dns_list.txt` — your whitelist (same format as before)
- `requirements-optional.txt` — optional deps for tray/encryption
- `logs/` — auto-created; contains `ipvtri_dns.log` and CSV if enabled

## Install optional features
```bash
pip install -r requirements-optional.txt
```

## Examples
```bash
# verbose debugging + tray + CSV + DoH
python ipvtri_dns_super_changer_PRO.py --log-level DEBUG --tray --csv logs/my.csv --enforce-doh

# strict secure mode (never switch to untrusted)
python ipvtri_dns_super_changer_PRO.py --strict-only-trusted --only-physical --encrypt-logs
```

## Notes
- DoH registration requires Windows 10/11 with DoH support.
- If `pystray`/`Pillow` aren’t installed, `--tray` is ignored with a warning.
- If `cryptography` isn’t installed, `--encrypt-logs` is ignored with a warning.