# 🌐 IPvTri+ Auto DNS Super Changer

**IPvTri+ Auto DNS Super Changer** is an intelligent DNS switching engine that combines color-encoded IP metadata, PowerShell-enhanced resolution testing, and adaptive fallback handling into one futuristic, self-healing loop.

---

## 🧠 What is IPvTri+?

IPvTri+ is a new approach to network address representation that encodes Red, Green, Blue, and Lightness metadata directly into IP addresses. This creates a hybrid identity system where every node or server has a **color fingerprint**, adding semantic meaning and visual traceability to traditional networking.

Example encoded IP:
```
[168:FF.111:FF.1:FF.1:FF] → #A86F01FF
```

---

## 🔧 Features

- ✅ Color-coded DNS entries (IPvTri+)
- ✅ Automatic fastest-DNS detection (A-record lookup via PowerShell)
- ✅ ICMP fallback mode if DNS is blocked or fails
- ✅ Visual CLI output with color swatches
- ✅ Auto interface detection (no config needed)
- ✅ Flushes DNS cache after switch
- ✅ Fully compatible with Windows 10+

---

## 📦 How to Use

1. Install Python 3.10+ and PowerShell (usually pre-installed on Windows).
2. Place `ipvtri_dns_super_changer.py` and `Run_IPvTri_DNS.bat` in the same folder.
3. Double-click `Run_IPvTri_DNS.bat` **or** run via terminal:

```
python ipvtri_dns_super_changer.py
```

> For color output: Windows Terminal or compatible ANSI console recommended.

---

## 🛠 Project Components

| File                         | Description                                       |
|-----------------------------|---------------------------------------------------|
| `ipvtri_dns_super_changer.py` | Core DNS rotation script with all advanced logic |
| `Run_IPvTri_DNS.bat`        | Windows launcher for double-click execution       |
| `README.md`                 | Project overview & documentation (this file)      |

---

## 🚀 Ideal For

- Mesh networks & intelligent overlay routing
- AI-driven infrastructure
- Visualized or color-coded access control
- High-security DNS switching environments
- Power users & researchers

---

## 📜 License

MIT License — Free to use, modify, and share.

---

## 🔮 Future Plans

- Cross-platform Linux/macOS compatibility
- Scheduled background daemon mode
- Web GUI for visualization
- Blockchain trust layer for DNS nodes

---

Built by @ChrisLandry | Project: **X-Spanded Ent.** | Powered by **IPvTri+** Networking Vision