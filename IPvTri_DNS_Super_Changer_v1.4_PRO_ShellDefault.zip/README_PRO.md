# IPvTri+ DNS Super Changer — PRO v1.4

## How to run (Default)
- Use the Desktop/Start Menu shortcut (points to **Run_IPvTri_DNS_PRO_SHELL.bat**).
- This keeps the console **open** so you can see output and run checks like `netsh interface ipv4 show dnsservers`.

## Alternate launchers
- `Run_IPvTri_DNS_PRO.bat`: robust direct launcher (auto-tray if deps present).
- `Run_IPvTri_DNS_PRO_SAFE.bat`: no tray/DoH/encryption/strict (debug mode).
- `diagnose_ipvtri.bat`: collects diagnostics into `logs/diagnostics.txt`.

## Optional features
- Run `install_optional_deps.bat` to enable tray icon + encrypted logs (`pystray`, `Pillow`, `cryptography`).
