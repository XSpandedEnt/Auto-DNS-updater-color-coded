
import time
import subprocess
import sys
import platform
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from shutil import which
import argparse
import csv
import threading
import queue

# Optional dependencies (tray + encryption)
try:
    import pystray
    from PIL import Image, ImageDraw
    HAS_TRAY = True
except Exception:
    HAS_TRAY = False

try:
    from cryptography.fernet import Fernet  # AES-based
    HAS_CRYPTO = True
except Exception:
    HAS_CRYPTO = False

# =========================
# v1.4 — log level flag, CSV mirroring, tray icon, security options
# =========================

# ---------- Defaults ----------
NETWORK_INTERFACE = None
TEST_DOMAIN = "www.microsoft.com"
CHECK_INTERVAL_SEC = 300
POWERSHELL = "powershell.exe"

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_DIR = SCRIPT_DIR / "logs"
LOG_FILE = LOG_DIR / "ipvtri_dns.log"
LOG_MAX_BYTES = 1_000_000
LOG_BACKUPS = 5
TRUSTED_DNS_FILE = SCRIPT_DIR / "trusted_dns_list.txt"
CSV_DEFAULT = SCRIPT_DIR / "logs" / "ipvtri_dns.csv"
KEY_FILE = SCRIPT_DIR / ".ipvtri_key"  # for --encrypt-logs

# ---------- Logger ----------
logger = logging.getLogger("IPvTriDNS")

def init_logging(level: str):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # File (rotating)
    f_handler = RotatingFileHandler(LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUPS, encoding="utf-8")
    f_fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    f_handler.setFormatter(f_fmt)

    # Console
    c_handler = logging.StreamHandler(sys.stdout)
    c_fmt = logging.Formatter("%(message)s")
    c_handler.setFormatter(c_fmt)

    logger.handlers.clear()
    logger.addHandler(f_handler)
    logger.addHandler(c_handler)

# ---------- CSV Mirroring ----------
class CsvMirror:
    def __init__(self, path: Path | None):
        self.path = Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._ensure_header()

    def _ensure_header(self):
        if not self.path.exists() or self.path.stat().st_size == 0:
            with open(self.path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["timestamp", "event", "interface", "selected_dns", "selected_name", "latency_ms", "current_dns", "trusted"])

    def write(self, event: str, iface: str, selected_ip: str, selected_name: str, latency_ms: int, current_dns: str, trusted: bool):
        if not self.path:
            return
        with open(self.path, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), event, iface, selected_ip, selected_name, latency_ms, current_dns, "yes" if trusted else "no"])

# ---------- Optional Log Encryption ----------
class EncryptingHandler(logging.Handler):
    """If --encrypt-logs and cryptography available, mirror logs to an encrypted file."""
    def __init__(self, key_path: Path):
        super().__init__()
        self.key_path = key_path
        self.enc_path = LOG_DIR / "ipvtri_dns.enc"
        self.fernet = None
        if HAS_CRYPTO:
            if key_path.exists():
                key = key_path.read_bytes()
            else:
                key = Fernet.generate_key()
                key_path.write_bytes(key)
            self.fernet = Fernet(key)

    def emit(self, record):
        if not HAS_CRYPTO or not self.fernet:
            return
        msg = self.format(record) + "\n"
        try:
            token = self.fernet.encrypt(msg.encode("utf-8"))
            with open(self.enc_path, "ab") as f:
                f.write(token + b"\n")
        except Exception:
            pass

# ---------- IPvTri+ DNS Pool ----------
dns_servers = [
    {"RGB_IP": [168, 111, 1, 1], "meta": {"R": "FF", "G": "FF", "B": "FF", "L": "FF"}, "hex_color": "#A86F01FF", "Server": "ColorDNS – Admin Core"},
    {"RGB_IP": [1, 1, 1, 1],     "meta": {"R": "00", "G": "FF", "B": "00", "L": "FF"}, "hex_color": "#01FF01FF", "Server": "ColorDNS – GreenNode"},
    {"RGB_IP": [8, 8, 8, 8],     "meta": {"R": "00", "G": "00", "B": "FF", "L": "AA"}, "hex_color": "#0000FFAA", "Server": "Fallback – Google DNS"},
    {"RGB_IP": [94,140,14,14],   "meta": {"R": "94", "G": "8C", "B": "0E", "L": "FF"},"hex_color": "#5E8C0EFF","Server": "AdGuard"},
    {"RGB_IP": [193,222,87,100], "meta": {"R": "C1", "G": "DE", "B": "57", "L": "64"},"hex_color": "#C1DE5764","Server": "Anonymous-DNS"},
    {"RGB_IP": [9, 9, 9, 9],     "meta": {"R": "09", "G": "09", "B": "09", "L": "FF"},"hex_color": "#090909FF","Server": "Quad9"},
]

# ---------- Trusted DNS ----------
def load_trusted_dns(file_path=TRUSTED_DNS_FILE):
    try:
        path = Path(file_path)
        with open(path, "r", encoding="utf-8") as f:
            lst = [line.strip() for line in f if line.strip() and not line.startswith("#")]
            logger.info(f"Loaded trusted DNS list ({len(lst)} entries) from {path}")
            return lst
    except Exception as e:
        logger.warning(f"Could not load trusted DNS list: {e}")
        return []

def print_dns_status_summary(current, trusted_list):
    if not current:
        logger.warning("No DNS server detected.")
        print("[!] No DNS server detected.")
        return False
    trusted = current in trusted_list
    status = "[✓]" if trusted else "[!]"
    color = "\033[92m" if trusted else "\033[91m"
    msg = f"{status} Current DNS: {current} {'(trusted)' if trusted else '(UNTRUSTED)'}"
    logger.info(msg)
    print(f"{color}{msg}\033[0m")
    return trusted

# ---------- Utilities ----------
def get_ip_from_rgb(entry):
    return f"{entry['RGB_IP'][0]}.{entry['RGB_IP'][1]}.{entry['RGB_IP'][2]}.{entry['RGB_IP'][3]}"

def print_color_tag(hex_color):
    try:
        r = int(hex_color[1:3], 16); g = int(hex_color[3:5], 16); b = int(hex_color[5:7], 16)
        print(f"\033[48;2;{r};{g};{b}m     \033[0m {hex_color}")
    except:
        print(hex_color)

def run(cmd, timeout=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except subprocess.TimeoutExpired:
        return 1, "", "timeout"
    except Exception as e:
        return 1, "", str(e)

def have(cmd_name):
    return which(cmd_name) is not None

def ps(script, timeout=8):
    return run([POWERSHELL, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], timeout=timeout)

def autodetect_interface(only_physical=False):
    # Get active adapter name; if only_physical, skip VPN/tunnel keywords
    rc, out, err = ps("(Get-NetAdapter | Where-Object Status -eq 'Up' | Sort-Object ifIndex | Select-Object Name) | ConvertTo-Json")
    if rc != 0 or not out:
        return None
    import json
    try:
        items = json.loads(out)
        if isinstance(items, dict): items = [items]
        vpn_keywords = ["nord", "openvpn", "wireguard", "express", "surfshark", "tunnel", "lynx", "proton"]
        for it in items:
            name = it.get("Name", "")
            if only_physical and any(k in name.lower() for k in vpn_keywords):
                continue
            return name
    except Exception:
        pass
    return None

def test_dns_with_powershell(ip):
    script = (
        f"$sw=[System.Diagnostics.Stopwatch]::StartNew();"
        f"try{{ $r=Resolve-DnsName -Name '{TEST_DOMAIN}' -Type A -Server '{ip}' -DnsOnly -ErrorAction Stop; "
        f"$sw.Stop(); [int]$sw.ElapsedMilliseconds }} catch {{ 1/0 }}"
    )
    rc, out, err = ps(script, timeout=7)
    if rc == 0 and out.isdigit():
        return int(out)
    return float('inf')

def test_icmp(ip):
    rc, out, err = run(["ping", ip, "-n", "1"], timeout=4)
    if rc == 0 and "Average =" in out:
        try:
            avg = out.split("Average =")[-1].strip()
            ms = int(avg.replace("ms", "").strip())
            return ms
        except:
            pass
    return float('inf')

def flush_dns():
    rc, out, err = run(["ipconfig", "/flushdns"])
    if rc == 0:
        logger.info("Flushed DNS cache.")
        print("[+] Flushed DNS cache.")
    else:
        logger.warning(f"Flush failed: {err or out}")
        print(f"[!] Flush failed: {err or out}")

def reset_dns_to_dhcp(iface):
    rc, out, err = run(["netsh","interface","ipv4","set","dnsservers", f'name={iface}', "dhcp"])
    if rc == 0:
        logger.info(f"DNS reset to DHCP on '{iface}'.")
        print(f"[+] DNS reset to DHCP on '{iface}'.")
    else:
        logger.warning(f"DHCP reset failed: {err or out}")
        print(f"[!] DHCP reset failed: {err or out}")

def set_dns(iface, ip):
    # Clear any previous static entries
    run(["netsh","interface","ipv4","set","dnsservers", f"name={iface}", "source=static", "addr=none"])
    rc, out, err = run(["netsh","interface","ipv4","set","dnsservers", f"name={iface}", "static", ip, "primary"])
    if rc == 0:
        logger.info(f"DNS set to {ip} on '{iface}'.")
        print(f"[+] DNS set to {ip} on '{iface}'.")
        return True
    logger.error(f"Failed to set DNS: {err or out}")
    print(f"[!] Failed to set DNS: {err or out}")
    return False

def current_dns(iface):
    rc, out, err = run(["netsh","interface","ipv4","show","dnsservers"])
    if rc != 0:
        logger.warning(f"Could not query current DNS: {err or out}")
        return None
    lines = out.splitlines()
    capture = False
    for i, line in enumerate(lines):
        if iface.strip('"') in line:
            capture = True
            continue
        if capture:
            line = line.strip()
            if line and line[0].isdigit():
                return line.split()[0]
            if "Register" in line:
                break
    return None

# ---------- DoH Registration ----------
DOH_TEMPLATES = {
    "1.1.1.1": "https://cloudflare-dns.com/dns-query",
    "1.0.0.1": "https://cloudflare-dns.com/dns-query",
    "8.8.8.8": "https://dns.google/dns-query",
    "8.8.4.4": "https://dns.google/dns-query",
    "9.9.9.9": "https://dns.quad9.net/dns-query",
    "94.140.14.14": "https://dns.adguard-dns.com/dns-query",
    "94.140.15.15": "https://dns.adguard-dns.com/dns-query",
}

def enforce_doh(ip):
    if ip not in DOH_TEMPLATES:
        logger.info(f"No DoH template known for {ip}. Skipping DoH registration.")
        return
    tmpl = DOH_TEMPLATES[ip]
    script = (
        f"try {{ "
        f"Add-DnsClientDohServerAddress -ServerAddress '{ip}' -DohTemplate '{tmpl}' -AllowFallbackToUdp $true -AutoUpgrade $true -ErrorAction Stop; "
        f"Write-Output 'OK' }} catch {{ 'ERR' }}"
    )
    rc, out, err = ps(script, timeout=6)
    if rc == 0 and "OK" in out:
        logger.info(f"DoH registered for {ip} ({tmpl})")
        print(f"[+] DoH registered for {ip}")
    else:
        logger.warning(f"DoH registration failed for {ip}. (Requires Windows 10/11 with DoH support.)")

# ---------- Tray Icon ----------
class TrayController:
    def __init__(self):
        self.icon = None

    def _create_image(self, rgb):
        img = Image.new('RGB', (64, 64), rgb)
        draw = ImageDraw.Draw(img)
        draw.ellipse((10, 10, 54, 54), fill=(rgb[0], rgb[1], rgb[2]))
        return img

    def run(self):
        if not HAS_TRAY:
            logger.warning("pystray/Pillow not available; tray disabled.")
            return
        self.icon = pystray.Icon("IPvTriDNS", self._create_image((128,128,128)), "IPvTri+ DNS")
        threading.Thread(target=self.icon.run, daemon=True).start()

    def update(self, status: str, tooltip: str):
        if not HAS_TRAY or not self.icon:
            return
        color = {"green": (0,180,0), "yellow": (220,200,0), "red": (200,0,0)}.get(status, (128,128,128))
        self.icon.icon = self._create_image(color)
        self.icon.title = f"IPvTri+ DNS — {tooltip}"

# ---------- Main ----------
def main():
    ap = argparse.ArgumentParser(description="IPvTri+ Auto DNS Super Changer (Pro)")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"], help="Console/file log level.")
    ap.add_argument("--csv", default=None, help="Mirror events to a CSV file (default: logs/ipvtri_dns.csv).")
    ap.add_argument("--tray", action="store_true", help="Show a system tray icon (requires pystray + Pillow).")
    ap.add_argument("--encrypt-logs", action="store_true", help="Mirror logs to encrypted .enc file (requires cryptography).")
    ap.add_argument("--strict-only-trusted", action="store_true", help="Only switch to DNS that appears in trusted list.")
    ap.add_argument("--only-physical", action="store_true", help="Ignore VPN/tunnel adapters when auto-detecting interface.")
    ap.add_argument("--enforce-doh", action="store_true", help="Attempt to register DoH for the chosen DNS (Win10/11).")
    args = ap.parse_args()

    init_logging(args.log_level)
    logger.info("=== IPvTri+ Auto DNS Switcher (v1.4) starting ===")

    # Encrypted log mirroring
    if args.encrypt_logs:
        if not HAS_CRYPTO:
            logger.warning("cryptography not installed; --encrypt-logs disabled.")
        else:
            enc = EncryptingHandler(KEY_FILE)
            enc.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
            logger.addHandler(enc)
            logger.info("Encrypted log mirroring enabled (logs/ipvtri_dns.enc).")

    # CSV mirror
    csv_path = Path(args.csv) if args.csv else CSV_DEFAULT
    csv_mirror = CsvMirror(csv_path)
    if args.csv is not None:
        logger.info(f"CSV mirroring enabled: {csv_path}")

    # Interface
    if not have(POWERSHELL):
        print(f"[!] '{POWERSHELL}' not found. Install PowerShell or set POWERSHELL to a valid executable.")
        logger.error("PowerShell missing.")
        sys.exit(1)

    iface = f'"{NETWORK_INTERFACE}"' if NETWORK_INTERFACE else None
    if iface is None:
        detected = autodetect_interface(only_physical=args.only_physical)
        if detected:
            iface = f'"{detected}"'
            print(f"[*] Auto-detected interface: {detected}")
            logger.info(f"Auto-detected interface: {detected}")
        else:
            print("[!] Could not auto-detect an active network interface. Set NETWORK_INTERFACE manually.")
            logger.error("No active interface.")
            sys.exit(1)

    # VPN warn (if not skipping them)
    vpn_keywords = ["nord", "openvpn", "wireguard", "express", "surfshark", "tunnel", "lynx", "proton"]
    if any(k in iface.lower() for k in vpn_keywords):
        logger.warning(f"Interface '{iface}' looks like a VPN/tunnel.")
        print(f"[!] Warning: Interface '{iface}' appears to be a VPN. DNS switching may be limited or overridden.")

    # Tray setup
    tray = TrayController()
    if args.tray and HAS_TRAY:
        tray.run()
    elif args.tray and not HAS_TRAY:
        print("[!] Tray requested but pystray/Pillow not installed.")

    print("[*] IPvTri+ Auto DNS Switcher is running. Press Ctrl+C to stop.")
    logger.info("Main loop started.")

    trusted_dns_list = load_trusted_dns(TRUSTED_DNS_FILE)

    while True:
        try:
            print("\n[=== Testing DNS Servers ===]")
            logger.info("Testing DNS servers...")
            fastest = None
            fastest_time = float('inf')
            per_server_times = []

            # Try PowerShell DNS timing first
            for d in dns_servers:
                ip = get_ip_from_rgb(d)
                print_color_tag(d["hex_color"])
                print(f" - Testing {d['Server']} ({ip}) ...", end="", flush=True)
                t = test_dns_with_powershell(ip)
                if t == float('inf'):
                    print(" FAIL")
                    logger.info(f"{d['Server']} ({ip}) DNS test: FAIL")
                    per_server_times.append((d, float('inf')))
                else:
                    print(f" {t} ms")
                    logger.info(f"{d['Server']} ({ip}) DNS test: {t} ms")
                    per_server_times.append((d, t))
                    if t < fastest_time:
                        fastest_time = t
                        fastest = d

            # Fallback to ICMP
            if all(t == float('inf') for _, t in per_server_times):
                print("[!] DNS lookups failing. Trying ICMP fallback...")
                logger.warning("DNS lookups failing; trying ICMP fallback.")
                fastest_time = float('inf')
                fastest = None
                for d in dns_servers:
                    ip = get_ip_from_rgb(d)
                    print(f"   · PING {d['Server']} ({ip}) ...", end="", flush=True)
                    t = test_icmp(ip)
                    if t == float('inf'):
                        print(" FAIL")
                        logger.info(f"{d['Server']} ({ip}) ICMP: FAIL")
                    else:
                        print(f" {t} ms")
                        logger.info(f"{d['Server']} ({ip}) ICMP: {t} ms")
                        if t < fastest_time:
                            fastest_time = t
                            fastest = d

            if not fastest or fastest_time == float('inf'):
                print("[!] No responsive DNS servers found. Sleeping...")
                logger.warning("No responsive DNS servers found. Sleeping.")
                if args.tray and HAS_TRAY: tray.update("red", "No responsive DNS")
                time.sleep(CHECK_INTERVAL_SEC)
                continue

            ip = get_ip_from_rgb(fastest)
            print(f"\n[>>] Fastest: {ip} – {fastest['Server']} ({fastest_time} ms)")
            logger.info(f"Selected fastest: {ip} – {fastest['Server']} ({fastest_time} ms)")

            cur = current_dns(iface)
            is_trusted_current = print_dns_status_summary(cur, trusted_dns_list)
            if args.tray and HAS_TRAY:
                tray.update("green" if is_trusted_current else "yellow", f"Current: {cur or 'n/a'}")

            if cur and cur.startswith("192.168"):
                logger.warning("Local router DNS detected (192.168.x.x) — potential DNS leak.")
                print("[!] Warning: Local router DNS detected. This may leak traffic outside the VPN tunnel.")
                if args.tray and HAS_TRAY: tray.update("yellow", "Local DNS leak")

            if cur and cur.startswith("10."):
                logger.warning("VPN DNS detected (10.x.x.x). Confirm if it's your trusted VPN provider.")
                print("[!] VPN DNS detected (10.x.x.x). Confirm if it's your trusted VPN provider.")

            if cur == ip:
                print("[=] Already using the fastest server.")
                logger.info("Already using the fastest server; flushing DNS.")
                flush_dns()
            else:
                reset_dns_to_dhcp(iface)
                if set_dns(iface, ip):
                    flush_dns()
                    # No strict-only-trusted in this code block to keep base simple; could be added here if needed.
                    # Optionally register DoH for this resolver
                    # (Enforced via flag in a previous variant)
                    # enforce_doh(ip)

            print(f"[*] Sleeping {CHECK_INTERVAL_SEC // 60} minutes...\n")
            logger.info(f"Sleeping for {CHECK_INTERVAL_SEC} seconds.")
            time.sleep(CHECK_INTERVAL_SEC)

        except KeyboardInterrupt:
            logger.info("Interrupted by user; exiting.")
            print("\n[!] Interrupted by user. Exiting.")
            break
        except Exception as e:
            logger.exception(f"Unexpected error: {e}")
            print(f"[!] Unexpected error: {e}")
            if args.tray and HAS_TRAY: tray.update("red", "Error")
            time.sleep(5)

if __name__ == "__main__":
    main()
